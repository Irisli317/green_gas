import pandas as pd
from extraction.helper import get_files


class Catalogue:
    CDMS = {}

    def __init__(self, file):
        self.file = file
        self.catalogue_df = None
        self.initialize()

    def initialize(self):
        self.catalogue_df = pd.read_excel(self.file)

    def get_catalogue(self):
        return self.catalogue_df

    def get_all_cdms_as_list(self):
        return self.catalogue_df['CDM reference'].tolist()

    def get_by_cdm_reference(self, cdm):
        return self.catalogue_df.loc[self.catalogue_df['CDM reference'] == cdm].values.flatten().tolist()

    @staticmethod
    def load_all(path):
        catalogues = get_files(path)

        # iterate over all catalogues
        for catalogue in catalogues:
            path = f'{path}/{catalogue}'
            catalogue = Catalogue(path)
            cdms = catalogue.get_all_cdms_as_list()

            for cdm in cdms:
                Catalogue.add(catalogue.get_by_cdm_reference(cdm))

    @staticmethod
    def generate_key(cdm_info):
        return tuple(cdm_info)

    @staticmethod
    def add(cdm_info):
        Catalogue.CDMS[Catalogue.generate_key(cdm_info)] = cdm_info
