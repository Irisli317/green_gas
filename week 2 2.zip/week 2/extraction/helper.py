import os


def get_files(path):
    files = os.listdir(path)
    return files
